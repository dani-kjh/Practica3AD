
import java.util.Scanner;

import java.util.*;
import org.me.servicioimagen.Image;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author alumne
 */
public class ClienteEscritorio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
             
        
        boolean sortir = false;
        while (!sortir) {
            System.out.println("1 - Registrar Imatge");
            System.out.println("2 - Modificar Imatge");
            System.out.println("3 - Eliminar Imatge");
            System.out.println("4 - Llistar imatges");
            System.out.println("5 - Buscador d'imatges");
            System.out.println("6 - Exit");
            
            Scanner sc = new Scanner(System.in);
            int entrada = sc.nextInt();
            
            switch (entrada) {
                
                case 1:
                    Image result = new Image();
                    sc.nextLine();

                    System.out.println("Entra el títol");
                    result.setTitle(sc.nextLine());

                    System.out.println("Entra la descripció");
                    result.setDescription(sc.nextLine());

                    System.out.println("Entra els tags (separats per ';')");
                    result.setKeywords(sc.nextLine());

                    System.out.println("Entra l'autor");
                    result.setAuthor(sc.nextLine());

                    System.out.println("Entra la data de creació (format dd/mm/aaaa)");
                    result.setCaptureDate(sc.nextLine());

                    System.out.println(registerImage(result));

                    // Username
                    // Filename
                    // ID
                    break;

                
                case 2:
                    System.out.println("Entra la ID de la imatge a modificar");
                    Image resultat = new Image();
                    resultat = searchById(sc.nextInt());
                    boolean acabat = false;
                    while (!acabat) {
                        System.out.println("-- Sel·lecciona el camp que vols modificar --");
                        System.out.println("1. Títol: " + resultat.getTitle());
                        System.out.println("2. Descripció: " + resultat.getDescription());
                        System.out.println("3. Autor: " + resultat.getAuthor());
                        System.out.println("4. Data creació: " + resultat.getCaptureDate());
                        System.out.println("5. Tags: " + resultat.getKeywords());
                        System.out.println("6. Sortir ");
                        System.out.println(" ");

                        int valor = sc.nextInt();
                        Scanner mod = new Scanner(System.in);
                        switch (valor) {
                            case 1:
                                System.out.println("Entra el nou títol");
                                resultat.setTitle(mod.nextLine());
                                break;
                            case 2:
                                System.out.println("Entra la nova descripció:");
                                resultat.setDescription(mod.nextLine());
                                break;
                            case 3:
                                System.out.println("Entra el nou autor:");
                                resultat.setAuthor(mod.nextLine());
                                break;
                            case 4:
                                System.out.println("Entra la nova data de creació (format 2018-10-26):");
                                resultat.setCaptureDate(mod.nextLine());
                                break;
                            case 5:
                                System.out.println("Entra els nous tags separats per ';':");
                                resultat.setKeywords(mod.nextLine());
                                break;
                            case 6:
                                acabat = true;
                                modifyImage(resultat);
                                break;
                        }
                    }

                    break;
                    
              case 3:
                    System.out.println("Entra la ID de la imatge a eliminar");
                    
                    deleteImage(sc.nextInt());    

                    break;
      

                    
            //Listar imagenes
                case 4:
                    List<Object> res = new ArrayList<Object>();
                    res = listImages();
                    Iterator<Object> it = res.iterator();

                    while (it.hasNext()) {
                        Object image = it.next();
                        Image mobj = Image.class.cast(image);
                        System.out.println("Id: " + mobj.getId());
                        System.out.println("Títol: " + mobj.getTitle());
                        System.out.println("Descripció: " + mobj.getDescription());
                        System.out.println("Autor: " + mobj.getAuthor());
                        System.out.println("Data creació: " + mobj.getCaptureDate());
                        System.out.println("Tags: " + mobj.getKeywords());
                        System.out.println(" ");
                    }

                    break;
                    
                case 5:
                    System.out.println("1 - Buscar per Id");
                    System.out.println("2 - Buscar per Titol");
                    System.out.println("3 - Buscar per Autor");
                    System.out.println("4 - Buscar per Tag");
                    System.out.println("5 - Buscar per Data");

                    int entrada2 = sc.nextInt();
                    Scanner sc2 = new Scanner(System.in);
                    switch (entrada2) {
                        case 1:
                            System.out.println("Introdueix la ID");
                            int entradaaux1 = sc.nextInt();

                            Object image = searchById(entradaaux1);
                            Image mobj = Image.class.cast(image);
                            System.out.println("Títol: " + mobj.getTitle());
                            System.out.println("Descripció: " + mobj.getDescription());
                            System.out.println("Autor: " + mobj.getAuthor());
                            System.out.println("Data creació: " + mobj.getCaptureDate());
                            System.out.println("Tags: " + mobj.getKeywords());
                            System.out.println(" ");

                            break;
                            
                        case 2:
                            System.out.println("Introdueix el títol");
                            String entradaaux2 = sc2.nextLine();
                            List<Object> resultataux2 = new ArrayList<Object>();
                            resultataux2 = searchByTitle(entradaaux2);
                            Iterator<Object> itaux2 = resultataux2.iterator();

                            while (itaux2.hasNext()) {
                                Object imageaux2 = itaux2.next();
                                Image mobjaux2 = Image.class.cast(imageaux2);
                                System.out.println("Títol: " + mobjaux2.getTitle());
                                System.out.println("Descripció: " + mobjaux2.getDescription());
                                System.out.println("Autor: " + mobjaux2.getAuthor());
                                System.out.println("Data creació: " + mobjaux2.getCaptureDate());
                                System.out.println("Tags: " + mobjaux2.getKeywords());
                                System.out.println(" ");
                            }
                            break;
                            
                            
                        case 3:
                            System.out.println("Introdueix l'autor");
                            String entradaaux3 = sc2.nextLine();
                            List<Object> resultataux3 = new ArrayList<Object>();
                            resultataux3 = searchByAuthor(entradaaux3);
                            Iterator<Object> itaux3 = resultataux3.iterator();

                            while (itaux3.hasNext()) {
                                Object imageaux2 = itaux3.next();
                                Image mobjaux2 = Image.class.cast(imageaux2);
                                System.out.println("Títol: " + mobjaux2.getTitle());
                                System.out.println("Descripció: " + mobjaux2.getDescription());
                                System.out.println("Autor: " + mobjaux2.getAuthor());
                                System.out.println("Data creació: " + mobjaux2.getCaptureDate());
                                System.out.println("Tags: " + mobjaux2.getKeywords());
                                System.out.println(" ");

                            }
                            break;
                        case 4:
                            System.out.println("Introdueix el tag");
                            String entradaaux4 = sc2.nextLine();
                            List<Object> resultataux4 = new ArrayList<Object>();
                            resultataux4 = searchByKeywords(entradaaux4);
                            Iterator<Object> itaux4 = resultataux4.iterator();

                            while (itaux4.hasNext()) {
                                Object imageaux2 = itaux4.next();
                                Image mobjaux2 = Image.class.cast(imageaux2);
                                System.out.println("Títol: " + mobjaux2.getTitle());
                                System.out.println("Descripció: " + mobjaux2.getDescription());
                                System.out.println("Autor: " + mobjaux2.getAuthor());
                                System.out.println("Data creació: " + mobjaux2.getCaptureDate());
                                System.out.println("Tags: " + mobjaux2.getKeywords());
                                System.out.println(" ");
                            }
                            break;
                            
                        case 5:
                            System.out.println("Introdueix la data de creació");
                            String entradaaux5 = sc2.nextLine();
                            List<Object> resultataux5 = new ArrayList<Object>();
                            resultataux5 = searchByCreaDate(entradaaux5);
                            Iterator<Object> itaux5 = resultataux5.iterator();

                            while (itaux5.hasNext()) {
                                Object imageaux2 = itaux5.next();
                                Image mobjaux2 = Image.class.cast(imageaux2);
                                System.out.println("Títol: " + mobjaux2.getTitle());
                                System.out.println("Descripció: " + mobjaux2.getDescription());
                                System.out.println("Autor: " + mobjaux2.getAuthor());
                                System.out.println("Data creació: " + mobjaux2.getCaptureDate());
                                System.out.println("Tags: " + mobjaux2.getKeywords());
                                System.out.println(" ");
                            }
                            break;
                           
                        case 6:
                            sortir = true;
                            break;

                    }
                case 6:
                    sortir = true;
                    break;
                    
            }
        }
        
    }
    
    private static java.util.List<java.lang.Object> listImages() {
        try { 
            org.me.servicioimagen.ServicioImagenWS_Service service = new org.me.servicioimagen.ServicioImagenWS_Service();
            org.me.servicioimagen.ServicioImagenWS port = service.getServicioImagenWSPort();
            java.util.List<java.lang.Object> result = port.listImages();
            return result;
        } catch (Exception ex) {
            // TODO handle custom exceptions here
        }
        return null;
    }
    private static Image searchById(int id) {
        Image result = new Image();
        try { 
            org.me.servicioimagen.ServicioImagenWS_Service service = new org.me.servicioimagen.ServicioImagenWS_Service();
            org.me.servicioimagen.ServicioImagenWS port = service.getServicioImagenWSPort();
            
           result = port.searchbyId(id);
            return result;
        } catch (Exception ex) {
        }
        return result;
    }
    
     private static java.util.List<java.lang.Object> searchByTitle(java.lang.String title) {
         try { 
             org.me.servicioimagen.ServicioImagenWS_Service service = new org.me.servicioimagen.ServicioImagenWS_Service();
             org.me.servicioimagen.ServicioImagenWS port = service.getServicioImagenWSPort();
             java.util.List<java.lang.Object> result = port.searchByTitle(title);
             
             return result;
         } catch (Exception ex) {
             // TODO handle custom exceptions here
         }
         return null;
    }
     
      private static java.util.List<java.lang.Object> searchByCreaDate(java.lang.String creaDate) {
          try { // Call Web Service Operation
              org.me.servicioimagen.ServicioImagenWS_Service service = new org.me.servicioimagen.ServicioImagenWS_Service();
              org.me.servicioimagen.ServicioImagenWS port = service.getServicioImagenWSPort();
              java.util.List<java.lang.Object> result = port.searchByCreaDate(creaDate);
              
              return result;
          } catch (Exception ex) {
              // TODO handle custom exceptions here
          }
          return null;
    }
      
      private static java.util.List<java.lang.Object> searchByKeywords(java.lang.String keywords) {
          try { // Call Web Service Operation
              org.me.servicioimagen.ServicioImagenWS_Service service = new org.me.servicioimagen.ServicioImagenWS_Service();
              org.me.servicioimagen.ServicioImagenWS port = service.getServicioImagenWSPort();
              java.util.List<java.lang.Object> result = port.searchByKeywords(keywords);
              
              return result;
          } catch (Exception ex) {
              // TODO handle custom exceptions here
          }
          return null;
    }
      
    private static java.util.List<java.lang.Object> searchByAuthor(java.lang.String author) {
        
        try { // Call Web Service Operation
            org.me.servicioimagen.ServicioImagenWS_Service service = new org.me.servicioimagen.ServicioImagenWS_Service();
            org.me.servicioimagen.ServicioImagenWS port = service.getServicioImagenWSPort();
            java.util.List<java.lang.Object> result = port.searchByAuthor(author);
            
            return result;
        } catch (Exception ex) {
            // TODO handle custom exceptions here
        }
        return null;

    }
    
    private static int registerImage(Image image) {
        
        try { // Call Web Service Operation
            org.me.servicioimagen.ServicioImagenWS_Service service = new org.me.servicioimagen.ServicioImagenWS_Service();
            org.me.servicioimagen.ServicioImagenWS port = service.getServicioImagenWSPort();
            //Necesario para los requisitos not null de la BD, en la app web no es necesario
            image.setCreator("Silvia");
            image.setFilename("prueba.png");
            int result = port.registerImage(image);
            return result;
        } catch (Exception ex) {
            // TODO handle custom exceptions here
        }
        return 25;
    }
    
     private static int modifyImage(Image image) {
         
         try { // Call Web Service Operation
             org.me.servicioimagen.ServicioImagenWS_Service service = new org.me.servicioimagen.ServicioImagenWS_Service();
             org.me.servicioimagen.ServicioImagenWS port = service.getServicioImagenWSPort();
             int result = port.modifyImage(image);
             return result;
         } catch (Exception ex) {
             // TODO handle custom exceptions here
         }
         return 256;
    }
     
     private static int deleteImage(int id){
         
         try { 
             org.me.servicioimagen.ServicioImagenWS_Service service = new org.me.servicioimagen.ServicioImagenWS_Service();
             org.me.servicioimagen.ServicioImagenWS port = service.getServicioImagenWSPort();
             
             return port.deleteImage(id);
            
         } catch (Exception ex) {
             // TODO handle custom exceptions here
         }
         return 0;
     }

}
    

